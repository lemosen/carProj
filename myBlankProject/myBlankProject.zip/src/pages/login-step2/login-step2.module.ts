import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { LoginStep2Page } from './login-step2';

@NgModule({
  declarations: [
    LoginStep2Page,
  ],
  imports: [
    IonicPageModule.forChild(LoginStep2Page),
  ],
})
export class LoginStep2PageModule {}
